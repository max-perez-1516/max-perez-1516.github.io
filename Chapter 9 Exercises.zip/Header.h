//
//  Header.h
//  9.21
//
//  Created by Max Perez on 4/23/18.
//  Copyright © 2018 Max Perez. All rights reserved.
//

#ifndef Header_h
#define Header_h


#endif /* Header_h */

class IntegerSet {
public:
    IntegerSet() {
        emptySet();
    }
    IntegerSet(int, int = -1, int = -1, int = -1, int = -1);
    IntegerSet unionOfSets(const IntegerSet&);
    IntegerSet intersectionOfIntegerSets(const IntegerSet&);
    void emptySet(void);
    void inputSet(void);
    void insertElement(int);
    void deleteElement(int);
    void setPrint(void) const;
    bool isEqualTo(const IntegerSet&) const;
private:
    int set[101];
    int vEntry(int x) const {
        return x >= 0 && x <= 100;
    }
};


