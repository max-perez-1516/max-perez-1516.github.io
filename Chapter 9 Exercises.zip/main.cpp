//
//  main.cpp
//  9.21
//
//  Created by Max Perez on 4/23/18.
//  Copyright © 2018 Max Perez. All rights reserved.
//
//
//
//  Using the Number "0" as false.
//  Using the Number "1" as true.
//
//
//
//
//


#include <iostream>
#include <iomanip>

using namespace std;

class IntegerSet {

public:
    IntegerSet() {
        emptySet();                                             // creates a new set of numbers with only 0's.
    }
    IntegerSet(int, int, int, int, int);                        // IntegerSet holds 5 ints (which will serve as our set variables).
    IntegerSet unionOfSets(const IntegerSet&);                  // This will test to see if the reference of a previous set is the "union of two sets"
    IntegerSet intersectionOfIntegerSets(const IntegerSet&);    // Tests to see if the reference of a previous set is a "theoretic intersection of sets"
    void emptySet(void);                                        // This will set all values of a set to 0.
    void inputSet(void);                                        // This will input values from user into a set.
    void insertElement(int);                                    // Inserts member function that places new int K into a setting a[k].
    void deleteElement(int);                                    // Member fuinction that deletes integer M in a set, replacing it with a 0.
    void setPrint(void) const;
    bool isEqualTo(const IntegerSet&) const;

private:
    int set[101];                                               // Set contains 101 values
    int vEntry(int x) const {                                   // Test for valid entry
        return x > 0 && x <= 100;
    }
};

void IntegerSet::inputSet(void) {                               // Function to input values into the sets.
    int num;
    cout << "Enter a number: ";                                 // Prompts user to input a number when function is called.
    cin >> num;
    
    if (vEntry(num)) {                                          // Testing the entered number for validity, against the vEntry function. If it
        set[num] = 1;                                           // passes the test and sets the entered number as a one in the set.
    }
    else if (num != 1) {                                        // If the number does not equal one at this point, then the entry is not valid.
        cout << "oops" << endl;
    }
}

void IntegerSet::emptySet(void) {                               // When called will set all values of set to 0.
    for (int i = 0; i < 101; i++)
        set[i] = 0;
}

IntegerSet IntegerSet::unionOfSets(const IntegerSet &r) {
    IntegerSet temp;                                            // Creating a temp vatiable for the IntegerSet object.
    for (int a = 0; a < 101; ++a)
        if(set[a] == 1 || r.set[a] == 1) {                      // If the set[a] and its copied reference hold the same values, then set the values of the new
            temp.set[a] = 1;                                    // temp variable in the object to 1.
        }
    return temp;                                                // Returns the varaible
}

void IntegerSet::setPrint(void) const {
    bool empty = true;                                          // Assuming that the set it empty
    
    for (int j = 0; j < 101; j++) {                             // Calls each set based on what is passed in the funtion parameter.
        if (set[j]) {                                           // Then outputs each value of the set when ran through the for loop.
            cout << j;                                          // Once the loop has been executed, the set is no longer empty.
            empty = false;                                      // empty is set to false.
        }
    }
}

IntegerSet IntegerSet::intersectionOfIntegerSets(const IntegerSet &r) {
    IntegerSet temp;                                            // Using the &r to look at and compare a copy of the set.
    
    for (int w = 0; w < 101; ++w)                               // This for loop checks to see if the new sets values are the same as the original
        if (set[w] == 1 && r.set[w] == 1)                       // IF the sets are the same, the new "temp' set will have 1's whereever the 'intersecting'
            temp.set[w] = 1;                                    // points are.
    return temp;
}

void IntegerSet::insertElement(int k) {
    if (vEntry(k)) {                                            // calling "valid memory" and using new element k of the set.
        set[k] = 1;                                             // Inserts entry if passes the valid entry criteria. Sets it to 1.
    }
    else {
        cout << "Invalid Input" << endl;                        // Outputs bad input
        }
    }

void IntegerSet::deleteElement(int m) {
    if (vEntry(m)) {
        set[m] = 0;                                             // Deletes element from set
    }
    else {
        cout << "Cannot Delete " << endl;                       // cannot delete if there is a 0 in for the set.
    }
}

bool IntegerSet::isEqualTo(const IntegerSet &r) const {
    for (int q = 0; q < 101; q++)                               // Checks a referenced copy of the set, against the original copy.
        if (set[q] != r.set[q])                                 // runs through a for loop for each value, checking the original vs the copy.
            return false;                                       // since the IntegerSet::isEqualTo is a bool, can return true or false once evaluated
        return true;                                            // making it a simple function to analyze.
}

IntegerSet::IntegerSet(int a, int b, int c, int d, int e) {
    emptySet();                                                 // Empties the set if already existing.
    if (vEntry(a)) {                                            // for the following:
        insertElement(a);                                       //                    checks to make sure the "int" inputs (a, b, c, d, e)
    }                                                           //                    are valid. If passed 'vEntry'. then the insertElement function
    if (vEntry(b)) {                                            //                    is called and executed.
        insertElement(a);
    }
    if (vEntry(c)) {
        insertElement(a);
    }
    if (vEntry(d)) {
        insertElement(a);
    }
    if (vEntry(e)) {
        insertElement(a);
    }
}


int main() {
    
    IntegerSet a, b, c, d, e;                                    // Creates a new IntegerSet that holds a, b, c, d, e.
    
    cout << "Enter Set A: ";                                     // Prompts user to enter value for set A.
    a.inputSet();                                                // calls inputSet function, passing the int A in.
    
    cout << "Enter Set B: ";                                     // Prompts user to enter value for set B.
    b.inputSet();                                                // calls inputSet function, passing the int B in.
    
    c = a.unionOfSets(b);                                        // Creates a copy of set A, passing in set B to check for "set-theoretic" union.
    d = a.intersectionOfIntegerSets(b);                          // Creates a copy of set A, passing in set B which compares both sets looking for any
                                                                 // duplicaiton.
    cout << "Untion of Sets A and B: ";
    c.setPrint();
    cout << "Intersection of Sets A and B: ";                    // These funtions are passed the c and d sets to the setPrint function which has already
    d.setPrint();                                                // ran the unionOfSets and intersectionOfIntegerSets. They are then printed out.
    
    if (a.isEqualTo(b)) {                                        // Passing the set a into the isEqualto function b, checking to see if they equal each other.
        cout << "Set A == Set B ";                               // IF they are equal, proceed to the cout, which outputs that both sets are equal.
    }
    else {
        cout << "Set A !== Set B ";                              // else, if the sets are not equal, then output. 
    }
    return 0;
}
    
    
    
    
    
    
    
